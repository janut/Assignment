import java.awt.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CardDeck{
	
	private String[] suits;
	private String[] rank;
	private String[] deck;
	protected ArrayList<String> playingdeck;
	protected boolean flag;

	
	// to load the cardDeck with CardType
	public CardDeck()
	{
		suits = new String[]{"S","D","C","H"};
		rank = new String[]{"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
		deck = new String[52];
		setPlayingdeck(new ArrayList<String>());
		
		
		for(int i=0; i<deck.length; i++)
		{
			deck[i] = rank[i%13] + suits[i/13];
			System.out.println(i + ". " +deck[i]);
		}
		
	}
	
	
	// to shuffle the cards
	public void shuffle()
	{
		
		for(int i=0; i<deck.length; i++)
		{
			int index = (int)(Math.random()*deck.length);
			String temp = deck[i];
			deck[i] = deck[index];
			deck[index] = temp;
		}
		
	
	}
	
	//to print the cards out
	
	public void printArray()
	{
		int count = 0;
		System.out.println("Shuffled card Deck:");
		for(String card:deck)
		{
			
			System.out.println((count++) +".   "+ card);
		}
	}
	
	// convert this string array into Arraylist
	public void Convert()
	{
		Collections.addAll(getPlayingdeck(), deck);
		//playingdeck = (ArrayList<String>) Arrays.asList(deck);
	}
	
	public void printArrayList()
	{
		int count = 0 ;
		for (String str: getPlayingdeck())
		{
			System.out.println(count++ + ". " + str);
		}
	}
	
	


	public ArrayList<String> getPlayingdeck() {
		return playingdeck;
	}


	public void setPlayingdeck(ArrayList<String> playingdeck) {
		this.playingdeck = playingdeck;
	}


	public boolean CheckGameStatus(Players a, Players b)
	{
		if((!playingdeck.isEmpty())|| ((!a.cardset.isEmpty())&&(!b.cardset.isEmpty())))
		{
			flag = true;
		}
		else
		{
			flag = false;
		}
		return flag;
	}

}
