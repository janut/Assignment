import java.util.Scanner;

public class CardGameTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int user_input;
	
	
		do
		{
		
			System.out.println("====================== GO FISH ======================");
			System.out.println("\n");
			System.out.println("                   1. Instructions                 ");
			System.out.println("                   2. Start Game                  ");
			System.out.println("                   3. Quit                  	   ");
			System.out.println("\n");
			System.out.println("====================== GO FISH ======================");
			System.out.println();
			System.out.print("Enter a number: ");
			user_input = input.nextInt();
		
				switch(user_input)
				{
				 case 1:
					 instructionDisplay();
					 break;
				 case 2:
					 	StartGame();
					 break;
				 case 3:
					 System.out.println("================================== GO FISH ====================================");
					 System.out.println("\n");
					 System.out.println("                       You have selected to quit this game!  ");
					 System.out.println("\n");
					 System.out.println("                           Thank You for Playing !!            ");
					 System.out.println("===============================================================================");
					 break;
				default:
					System.out.println("This is not a valid input!");
					break;
				}
		}while(user_input != 3);
		
		/*
		
		CardDeck game1 = new CardDeck();
		game1.shuffle();
		game1.printArray();
		
		game1.Convert();
		game1.printArrayList();
		Players computer = new Players();
		computer.dealCards(game1);
		game1.printArrayList();
		Players player1 = new Players();
		player1.dealCards(game1);
		game1.printArrayList();
		*/
		}

	// this method provides the instructions as to how to play the GoFish
	private static void instructionDisplay() {
		// TODO Auto-generated method stub
		System.out.println("================================== GO FISH RULES ====================================");
		System.out.println("In this game, you (Player 2) will be playing against the computer(Player 1).");
		System.out.println("Each player is dealt 7 cards. Player 2's card set is displayed on the screen.");
		System.out.println("A player is randomly selected to start the game. The player needs to ask the other");
		System.out.println("player for a particular rank that is found in their cardset. If the other player ");
		System.out.println("doesn't have the card, the player will say \"Go Fish!\"At this point, the player ");
		System.out.println("will draw 1 card from the deck. The game is played until all the cards are ");
		System.out.println("drawn and matched up! ");
		System.out.println("\n-------------------------------------  GOAL   ----------------------------------------");
		System.out.println("To collect all 4 cards for each rank found within your cardset.");
		System.out.println("\n------------------------------------  SCORING   --------------------------------------");
		System.out.println("When you collect all 4 cards of 1 rank, you will receive 1 point. ");
		System.out.println("The player with the most points, will win!");
		System.out.println("======================================================================================"); 
			
	}
	
	private static void StartGame()
	{
		//create the cards and shuffling it
		CardDeck game1 = new CardDeck();
		game1.shuffle();
		game1.printArray();
		game1.Convert();
		
		// dealing the cards to the players
		Players computer = new Players();
		computer.dealCards(game1);
		
		Players player1 = new Players();
		player1.dealCards(game1);
		
		boolean cards_result = true;
		boolean status = true;
		do
		{
		
			System.out.print("Player 1  ");
			player1.printHand();
			System.out.print("Computer  ");
			computer.printHand();
			
			//Computer takes the first turn
			computer.ComputerTurn(player1, computer, game1);
			//computer.printHand();
			computer.CheckCards(computer);
			//System.out.println("The drawing deck has: " + game1.playingdeck + "size of: " + game1.playingdeck.size());
			
			//Player takes the second turn
			player1.PlayerTurn(player1, computer,game1);
			player1.CheckCards(player1);
			
				
				
			status = game1.CheckGameStatus(player1, computer);
						
		}while(status);
	}
}
