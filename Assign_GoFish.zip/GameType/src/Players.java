import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Players extends CardDeck {
	
	protected ArrayList<String> cardset;
	protected int piles;
	protected int score;
	protected int numPlayers;
	protected boolean flag = true;
	//protected  ArrayList<String> drawingdeck;
	
	//initialize the player
	public Players()
	{
		cardset = new ArrayList<String>();
		piles = 0;
		score = 0;
		//drawingdeck = new ArrayList<String>();
		
	}
	
	public boolean dealCards(CardDeck a)
	{
		//deal 7 cards to the player, assuming there are only 2 players
		boolean dealcards = false;
		
		if((a.playingdeck.size()!=0) && (a.playingdeck.size()>7) && (cardset.size()==0))
		{
			for (int i =0; i<7; i++)
			{
				// need to remove from just the beginning of the array because the Arraylist will adjust on its own
				String temp = a.getPlayingdeck().remove(0);
				cardset.add(temp);
				System.out.println("Card removed: "+ temp);
				
			}
						//drawingdeck = a.playingdeck;
			dealcards = true;
		}
		else if((a.playingdeck.size()!=0) && (a.playingdeck.size()<7 )&&(cardset.size()==0))
		{
			for (int i =0; i<a.playingdeck.size(); i++)
			{
				// need to remove from just the beginning of the array because the Arraylist will adjust on its own
				String temp = a.getPlayingdeck().remove(0);
				cardset.add(temp);
				System.out.println("Card removed: "+ temp);
				
			}
			dealcards = true;
		}
		else
		{
			dealcards = false;
		}
			
		return dealcards;
	}
	
	
	public void printHand()
	{
		System.out.println(" , the cards are: " + cardset);
	}

	
	public void ComputerTurn(Players a, Players computer, CardDeck set)
	{
		boolean askagain = true;
		boolean dealtcards = true;
		char rank;
		// generate a different random number every time the method is called
		Random rn = new Random();
		int num;
		
		do
		{
			if(a.cardset.size()==0)
			{
				dealtcards = a.dealCards(set);
			}
			
			//based on the size of the computer's card set, it will randomly pick a number and use that number as an index
			num = rn.nextInt(computer.cardset.size()-1);
			System.out.println("Computer, your cards are: " + computer.cardset);
			//System.out.println("The card number is: " + num );
			
			String temp = computer.cardset.get(num);
			rank = temp.charAt(0);
			System.out.println("Player 1, do you have " + rank + "?");
			askagain = ComputerScan(rank, a, computer, set);
			
			
			
		}while(askagain && dealtcards);
			CheckCards(computer);
			
					
	}
	
	//Computer scans the Player's deck to see if the card requested by the computer is found
	//if there is match, the card is removed from the player and placed in the computer's cardset
	public boolean ComputerScan(char rank, Players a, Players computer, CardDeck set)
	{
		boolean askagain = false;
		int cardset_size = computer.cardset.size();
		
		String handingcard;
		for(int i = 0; i<a.cardset.size(); i++)
		{
			
			if(rank ==(a.cardset.get(i).charAt(0)))
			{
				computer.cardset.add(a.cardset.get(i));
				handingcard = a.cardset.remove(i);
				i--;
				
				
				System.out.println("Computer took this card from player: " + handingcard);

				askagain = true;
				
			}
			
		}	
		//System.out.println("initial card_size: " + cardset_size);
		//System.out.println("final card size: " + computer.cardset.size());
		System.out.println("playing deck size: " + set.playingdeck.size());
				//if there is no match, the computer draws a card from the deck
				//if the drawing deck is not empty then draw a card from deck and place it in computer's hand set
				if((cardset_size == computer.cardset.size()) && (set.playingdeck.size()!= 0))
				{
					
				
					String temp = set.playingdeck.remove(0);
					computer.cardset.add(temp);
					System.out.println("Player doesn't have the card.");
					System.out.println("Computer drew a card from deck: " + temp);
					askagain = false;
				}
				
				return askagain;
	}
	
	//The two methods used by the Player: PlayerTurn and PlayerScan
	public void PlayerTurn(Players a, Players computer, CardDeck set)
	{
			boolean askagain = true;
			boolean dealtcards = true;
			do{
			Scanner input = new Scanner(System.in);
			char rank;
			String card;
			
			if(computer.cardset.size()==0)
			{
				dealtcards = computer.dealCards(set);
			}
			// ask user to enter a number they want to ask the other player
			System.out.println("Your cards are: " + a.cardset);
			System.out.println("Please enter the rank: ");
			card = input.nextLine();
			rank = card.charAt(0);
			
		
			System.out.println("Computer, do you have " + rank + "?");
			askagain = PlayerScan(rank, a, computer, set);
			}while(askagain && dealtcards); 
			CheckCards(a);
					
	}
	
	//Computer scans the Player's deck to see if the card requested by the computer is found
		//if there is match, the card is removed from the player and placed in the computer's cardset
		public boolean PlayerScan(char rank, Players a, Players computer, CardDeck set)
		{
			int cardset_size = a.cardset.size();
			String handingcard;
			boolean askagain = true;
			//check if the computer has a set of cards before you search it
			
			if(computer.cardset.size()!=0)
			{
				// search the computer set of cards
				for(int i = 0; i<computer.cardset.size(); i++)
				{
					if(rank ==(computer.cardset.get(i).charAt(0)))
					{
						
						a.cardset.add(computer.cardset.get(i));
						handingcard = computer.cardset.remove(i);
						i--;
						System.out.println("Player took a card from Computer: "+ handingcard);
	
						askagain = true;
						
					}
					
				}	
			}
				
						//if there is no match, the computer draws a card from the deck
						//if the drawing deck is not empty then draw a card from deck and place it in computer's hand set
						if((cardset_size == a.cardset.size()) && (set.playingdeck.size()!= 0))
							
						{
						
							String temp = set.playingdeck.remove(0);
							a.cardset.add(temp);
							System.out.println("Computer doesn't have the card.");
							System.out.println("Player drew a card from deck: "+ temp);
							askagain = false;
							
						}
						
						
		
			
			return askagain;
		}
		
		public void CheckCards(Players player)
		{
			String cur_card;
			String next_card;
			char next_rank;
			char cur_rank;
			int count = 0;
			int [] removeindex = new int[20];
			String[] removecard = new String[20];
			//removecard = null;
			int index = 0;
			
			int size = player.cardset.size();
			
			
			for(int i = 0; i< size; i++)
			{
				cur_card = player.cardset.get(i);
				cur_rank = cur_card.charAt(0);
				
				for(int j= 0; j<size; j++)
				{
					next_card = player.cardset.get(j);
					next_rank = next_card.charAt(0);
					if(i!=j)
					{
						if(cur_rank == next_rank)
						{
							count++;
							//System.out.println("Are you coming into the CardCheck?");
							//System.out.println("What's the current rank? " + cur_rank + count);
							//System.out.println("current rank : next_rank  " + cur_rank + "  "+ next_rank);
						}
						// if there are 3 other matching cards, then it stores the number in the array
						
						if(count==3)
						{
							removecard[index++] = cur_card;
							
						}
					}
				}
			
				count = 0;
				
			}
			
			if(removecard[0]!= null)
			{
				System.out.println("Are you coming into the method where player has 4 of the same?");
				int remove_count = 0;
				for(int k = 0; k<removecard.length; k++)
				{
					for(int m = 0; m < player.cardset.size(); m++)
					{
						if(removecard[k]== player.cardset.get(m))
						{
							player.cardset.remove(k);
						}
					}
				}
				// if 4 cards of the same rank then it creates 1 pile and player receives a score of 1
				player.piles++;
				player.score++;
			}
			
			
			
		}
		
		
				
		
		
}


